MatterSlice
===========

This is a c# command line slicing engine. It uses clipper for much of the heavy lifting and is has no other external dependencies. It is a c# port of the CuraEngine which is a c++ translation of Skienforge. The goal of this library is to be a fast and easy to edit slicing engine for consumer desktop 3D printers.
