﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RepetierHost.extensions
{
    public class ExtensionManager
    {
        public static void Initalize()
        {
        }
    }
}
